# Employee-CRUD-in-Spring-Boot

- this is a simple crud in spring boot and mysql
- i used xampp control panel. xampp has mysql inside it
- i enable apache server and configure port in appliocation.propeties = server.port = 9999

## step by step

- create db name springbootemployee in phpmyadmin
- then import springbootemployee.sql
- open terminal run mvn spring-boot


## screenshot

<img width="1280" alt="screen shot 2018-03-18 at 12 42 54 pm" src="https://user-images.githubusercontent.com/12325386/37562852-fb54a274-2aac-11e8-95c5-cd525d510c88.png">


<img width="1256" alt="screen shot 2018-03-18 at 12 36 46 pm" src="https://user-images.githubusercontent.com/12325386/37562855-0746736e-2aad-11e8-80e0-c9eaba653a67.png">

<img width="1256" alt="screen shot 2018-03-18 at 12 37 42 pm" src="https://user-images.githubusercontent.com/12325386/37562856-0788b4c2-2aad-11e8-8453-373db3dbc057.png">

<img width="1008" alt="screen shot 2018-03-18 at 12 39 45 pm" src="https://user-images.githubusercontent.com/12325386/37562857-07beb8ec-2aad-11e8-95c3-7e9455c5598c.png">
