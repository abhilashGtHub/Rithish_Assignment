package com.ahmadsolehin.SUSAHCRUDNIE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SusahcrudnieApplication {

	public static void main(String[] args) {
		SpringApplication.run(SusahcrudnieApplication.class, args);
	}
}
