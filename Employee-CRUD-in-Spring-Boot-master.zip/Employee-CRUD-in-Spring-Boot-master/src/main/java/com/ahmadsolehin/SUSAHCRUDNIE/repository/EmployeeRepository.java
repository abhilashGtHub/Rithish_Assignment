package com.ahmadsolehin.SUSAHCRUDNIE.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ahmadsolehin.SUSAHCRUDNIE.model.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

    List<Employee> findByNameContaining(String q);
    
    @Query(value = "SELECT * FROM Employee WHERE search_key like %?1%",	    
    	    nativeQuery = true)
    List<Employee> findBySearchKey(String q);

}